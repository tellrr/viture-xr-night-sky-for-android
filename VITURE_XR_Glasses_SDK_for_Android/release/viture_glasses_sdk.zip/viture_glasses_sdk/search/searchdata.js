var indexSectionsWithContent =
{
  0: "cdfghilmpstvwx",
  1: "x",
  2: "mv",
  3: "x",
  4: "dfhstw",
  5: "glvx",
  6: "x",
  7: "x",
  8: "cdgipstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

