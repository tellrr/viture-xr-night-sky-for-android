var searchData=
[
  ['xr_5fcamera_5fformat_5fgray_0',['XR_CAMERA_FORMAT_GRAY',['../viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845a0b5100e2980d6d8ac849029f88c31e04',1,'viture_camera_provider.h']]],
  ['xr_5fcamera_5fformat_5fmjpeg_1',['XR_CAMERA_FORMAT_MJPEG',['../viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845aa2d33e255388e5955fb238834169cacb',1,'viture_camera_provider.h']]],
  ['xr_5fcamera_5fformat_5fnv12_2',['XR_CAMERA_FORMAT_NV12',['../viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845a95b4ecd38da85dbb6e0892fa623c2019',1,'viture_camera_provider.h']]],
  ['xr_5fcamera_5fformat_5frgb_3',['XR_CAMERA_FORMAT_RGB',['../viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845aaf53db9ef8a09b6915dcfee661e1a4c0',1,'viture_camera_provider.h']]],
  ['xr_5fcamera_5fformat_5fyuyv_4',['XR_CAMERA_FORMAT_YUYV',['../viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845a5684843c72062431739d127e6bcf4a83',1,'viture_camera_provider.h']]],
  ['xr_5fdevice_5ftype_5fviture_5fcarina_5',['XR_DEVICE_TYPE_VITURE_CARINA',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea1231a632c9a7b53c9b1d384d57ae2590',1,'viture_glasses_provider.h']]],
  ['xr_5fdevice_5ftype_5fviture_5fgen1_6',['XR_DEVICE_TYPE_VITURE_GEN1',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea0551526d67deed27f08de249e886ae09',1,'viture_glasses_provider.h']]],
  ['xr_5fdevice_5ftype_5fviture_5fgen2_7',['XR_DEVICE_TYPE_VITURE_GEN2',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea0e4ccea9e04cf2c1af3f0948dd074c2d',1,'viture_glasses_provider.h']]]
];
