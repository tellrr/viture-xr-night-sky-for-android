var searchData=
[
  ['sdk_0',['Welcome to Viture Glasses SDK',['../index.html',1,'']]],
  ['sequence_1',['sequence',['../structXRCameraFrame.html#ac6d48c29b17af9ab9d203aea005dfec4',1,'XRCameraFrame']]],
  ['size_2',['size',['../structXRCameraFrame.html#ac327bcb36cd756ecb6ad9b68f7f444b4',1,'XRCameraFrame']]]
];
