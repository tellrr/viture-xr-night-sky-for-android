var searchData=
[
  ['timestamp_0',['timestamp',['../structXRCameraFrame.html#a4503cff65bc32dbbb7c55277f00167fe',1,'XRCameraFrame']]]
];
