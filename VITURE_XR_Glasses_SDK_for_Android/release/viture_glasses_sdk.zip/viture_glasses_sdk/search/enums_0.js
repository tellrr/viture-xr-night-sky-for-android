var searchData=
[
  ['xrcameraformat_0',['XRCameraFormat',['../viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845',1,'viture_camera_provider.h']]],
  ['xrdevicetype_1',['XRDeviceType',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3e',1,'viture_glasses_provider.h']]]
];
