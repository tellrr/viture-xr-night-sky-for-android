var structXRCameraFrame =
[
    [ "data", "structXRCameraFrame.html#abf54f2a63f02868db252fd3d557f62c0", null ],
    [ "format", "structXRCameraFrame.html#aa843ee205dad6656949097f86134ac94", null ],
    [ "height", "structXRCameraFrame.html#a3f1926afbc776f6eca57f510b4055635", null ],
    [ "sequence", "structXRCameraFrame.html#ac6d48c29b17af9ab9d203aea005dfec4", null ],
    [ "size", "structXRCameraFrame.html#ac327bcb36cd756ecb6ad9b68f7f444b4", null ],
    [ "timestamp", "structXRCameraFrame.html#a4503cff65bc32dbbb7c55277f00167fe", null ],
    [ "width", "structXRCameraFrame.html#ab1a9ba299eefffe8c0efa79e32c65cdb", null ]
];