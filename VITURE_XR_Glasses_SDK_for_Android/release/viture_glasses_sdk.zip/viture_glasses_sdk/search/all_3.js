var searchData=
[
  ['glasses_20sdk_0',['Welcome to Viture Glasses SDK',['../index.html',1,'']]],
  ['glassstatecallback_1',['GlassStateCallback',['../viture__glasses__provider_8h.html#a2ea8b0f6cf78fed4b748b4abb93a4902',1,'viture_glasses_provider.h']]]
];
