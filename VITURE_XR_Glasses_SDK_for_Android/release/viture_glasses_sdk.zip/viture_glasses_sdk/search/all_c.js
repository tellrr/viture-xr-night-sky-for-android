var searchData=
[
  ['welcome_20to_20viture_20glasses_20sdk_0',['Welcome to Viture Glasses SDK',['../index.html',1,'']]],
  ['width_1',['width',['../structXRCameraFrame.html#ab1a9ba299eefffe8c0efa79e32c65cdb',1,'XRCameraFrame']]]
];
