var searchData=
[
  ['xrcameracallback_0',['XRCameraCallback',['../viture__device__carina_8h.html#a3da81c868e950cdfbcae27220e10215b',1,'viture_device_carina.h']]],
  ['xrcameraframecallback_1',['XRCameraFrameCallback',['../viture__camera__provider_8h.html#a8e7135bc4a4ca437531f3903b09ee80e',1,'viture_camera_provider.h']]],
  ['xrcameraproviderhandle_2',['XRCameraProviderHandle',['../viture__camera__provider_8h.html#a3854e5d42749e32021c40e556cde1c0a',1,'viture_camera_provider.h']]],
  ['xrdeviceproviderhandle_3',['XRDeviceProviderHandle',['../viture__glasses__provider_8h.html#a673cef8049a5e15343c066644d99fb8c',1,'XRDeviceProviderHandle:&#160;viture_glasses_provider.h'],['../viture__protocol__public_8h.html#a673cef8049a5e15343c066644d99fb8c',1,'XRDeviceProviderHandle:&#160;viture_protocol_public.h']]],
  ['xrimucallback_4',['XRImuCallback',['../viture__device__carina_8h.html#ad123adcc0bfc931b25e3c9253a09055a',1,'viture_device_carina.h']]],
  ['xrposecallback_5',['XRPoseCallback',['../viture__device__carina_8h.html#a956d45f28cae4b0a97f2caeb2a1b4590',1,'viture_device_carina.h']]],
  ['xrvsynccallback_6',['XRVSyncCallback',['../viture__device__carina_8h.html#a829c8bda583fe1d4ecc9dc056b8a8105',1,'viture_device_carina.h']]]
];
