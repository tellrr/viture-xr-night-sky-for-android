var viture__device__carina_8h =
[
    [ "XRCameraCallback", "viture__device__carina_8h.html#a3da81c868e950cdfbcae27220e10215b", null ],
    [ "XRImuCallback", "viture__device__carina_8h.html#ad123adcc0bfc931b25e3c9253a09055a", null ],
    [ "XRPoseCallback", "viture__device__carina_8h.html#a956d45f28cae4b0a97f2caeb2a1b4590", null ],
    [ "XRVSyncCallback", "viture__device__carina_8h.html#a829c8bda583fe1d4ecc9dc056b8a8105", null ],
    [ "xr_device_provider_get_gl_pose_carina", "viture__device__carina_8h.html#a1c18f40bf034d32cc720816f9dd9655f", null ],
    [ "xr_device_provider_register_callbacks_carina", "viture__device__carina_8h.html#aaccd3152833c066dc210dc078507de2c", null ],
    [ "xr_device_provider_reset_origin_carina", "viture__device__carina_8h.html#a89e7ebc0486482a751fa36e4d80431b6", null ],
    [ "xr_device_provider_reset_pose_carina", "viture__device__carina_8h.html#aee9e2601a2e875a0e3ea17fbeff9402c", null ],
    [ "xr_device_provider_set_dof_type_carina", "viture__device__carina_8h.html#ab3c46dba2b1bfbfa000cf028040155d8", null ]
];