var searchData=
[
  ['sequence_0',['sequence',['../structXRCameraFrame.html#ac6d48c29b17af9ab9d203aea005dfec4',1,'XRCameraFrame']]],
  ['size_1',['size',['../structXRCameraFrame.html#ac327bcb36cd756ecb6ad9b68f7f444b4',1,'XRCameraFrame']]]
];
